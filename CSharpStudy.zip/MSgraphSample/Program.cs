﻿using System;
using System.Threading.Tasks;

using Microsoft.Azure.ActiveDirectory.GraphClient;
using Microsoft.IdentityModel.Clients.ActiveDirectory;

namespace MSgraphSample
{
    class Program
    {
        static void Main(string[] args)
        {
            var graphResourceId = "https://graph.windows.net";
            var appId = "a4b1ef7f-be22-4a76-903e-d7c00726ab9e";
            var appObjectId = "766bec82-e7bd-459f-a038-c3ea1a6ef98e";
            var secret = "HBBy7RXi4wuppifM0XGwW1ziBgtVblPfFWmnJFyVdaw=";
            var clientCredential = new ClientCredential(appId, secret);
            var tenantId = "eygs.onmicrosoft.com";
            AuthenticationContext authContext = new AuthenticationContext($"https://login.microsoftonline.com/{tenantId}");
            var accessToken = authContext.AcquireTokenAsync(graphResourceId, clientCredential).Result.AccessToken;

            Uri servicePointUri = new Uri(graphResourceId);
            Uri serviceRoot = new Uri(servicePointUri, tenantId);

            ActiveDirectoryClient activeDirectoryClient = new ActiveDirectoryClient(serviceRoot, async () => await Task.FromResult(accessToken));

            var app = activeDirectoryClient.Applications.GetByObjectId(appObjectId).ExecuteAsync().Result;

            foreach (var passwordCredential in app.PasswordCredentials)
            {
                Console.WriteLine($"KeyID:{passwordCredential.KeyId}\r\nEndDate:{passwordCredential.EndDate}\r\n");
            }
        }
    }
}
