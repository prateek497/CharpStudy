﻿using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;

namespace LinqPractice
{
    class Program
    {
        static void Main(string[] args)
        {
            SampleViewModel model = new SampleViewModel(true);
            model.Join();
        }
    }

    static class EmployeeRepo
    {
        private static List<Employee> employees = new List<Employee>();

        static List<Employee> GetEmployees()
        {
            employees.Add(new Employee { FirstName = "Saroj", LastName = "Patnaik", State = "USA" });
            employees.Add(new Employee { FirstName = "Sandeep", LastName = "Sethi", State = "CA" });
            return employees;
        }
    }

    class ProductRepo
    {
        public static List<Products> GetAllProducts()
        {
            var productList = new List<Products>()
            {
                new Products {ProductId = 2345, ProductName = "TV", Size = 10},
                new Products() {ProductId = 3455, ProductName = "WATCH", Size = 15}
            };
            return productList;
        }
    }

    class SaleRepo
    {
        public static List<Sales> GetSalesList()
        {
            var saleList = new List<Sales>()
            {
                new Sales()
                {
                    ProductId = 2345,
                    SaleId = 1000,
                    TotalSale = 200
                },
                new Sales()
                {
                    ProductId = 3333,
                    SaleId = 67787,
                    TotalSale = 9000
                }
            };
            return saleList;
        }
    }
    class Employee
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string State { get; set; }
    }

    class Products
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int Size { get; set; }
        public int CommonField { get; set; }
    }

    class Sales
    {
        public int SaleId { get; set; }
        public int ProductId { get; set; }
        public int TotalSale { get; set; }
        public int CommonField { get; set; }
    }

    class SampleViewModel
    {
        public SampleViewModel(bool isQuerySyntax)
        {
            IsQuerySyntax = isQuerySyntax;
            Products = ProductRepo.GetAllProducts();
        }

        private bool IsQuerySyntax { get; set; }
        public List<Products> Products { get; set; }
        //
        public void GetSpecificColumns()
        {
            if (IsQuerySyntax)
            {
                Products = (from prod in Products
                            select new Products()
                            {
                                ProductId = prod.ProductId,
                                ProductName = prod.ProductName
                            }).ToList();
            }
            else
            {
                Products = Products.Select(prod => new Products()
                {
                    ProductId = prod.ProductId,
                    ProductName = prod.ProductName
                }).ToList();
            }
        }

        public dynamic AnonymousClass()
        {
            if (IsQuerySyntax)
            {
                var products = (from prod in Products
                                select new
                                {
                                    NewProductIdName = prod.ProductId,
                                    NewProductName = prod.ProductName,
                                    NewSizeName = prod.Size
                                }).ToList();
                return products;
            }
            else
            {
                var products = Products.Select(prod => new { NewProductId = TestMethod(prod.ProductId) }).ToList();
                return products;
            }
        }

        public int TestMethod(int productId)
        {
            return 1;
        }
        public void OrderBy()
        {
            if (IsQuerySyntax)
                Products = (from prod in Products
                            orderby prod.ProductName
                            select prod).ToList();
            else
            {
                Products = Products.OrderByDescending(prod => prod.ProductName).ToList();
            }
        }
        public void OrderByMultipleFields()
        {
            if (IsQuerySyntax)
                Products = (from prod in Products
                            orderby prod.ProductName descending, prod.Size
                            select prod).ToList();
            else
            {
                Products = Products.OrderByDescending(prod => prod.ProductName).ThenBy(prod => prod.Size).ToList();
            }
        }
        public void DistinctValue()
        {
            var productsNew = Products.Distinct().Select(prod => prod.Size);
        }
        public void All_Any()
        {
            var productsNew = Products.All(m => m.ProductName.StartsWith(" "));
            var productsNw = Products.Any(m => m.ProductName.StartsWith(" "));
        }


        public void Join()
        {
            var products = ProductRepo.GetAllProducts();
            var sales = SaleRepo.GetSalesList();
            var query = from prod in products
                            //So when we choose multiple fields u have to use anonymous type
                        join sale in sales on new { prod.ProductId, prod.CommonField } equals new { sale.ProductId, sale.CommonField }
                        select new
                        {
                            ProductName = prod.ProductName,
                            Sales = sale.TotalSale
                        };
        }

        public void LeftJoin()
        {
            var products = ProductRepo.GetAllProducts();
            var saleList = SaleRepo.GetSalesList();
            var query = from prod in Products
                join sale in saleList on prod.ProductId equals sale.ProductId
                    into sales
                from sale in saleList.DefaultIfEmpty()
                select new
                {
                    sale?.CommonField,
                    sale?.ProductId,
                    prod.Size
                };
        }
        /// <summary>
        /// Really useful when u want to have custom aggregate
        /// </summary>
        public void Aggregate()
        {
            var result = Products.Aggregate(0M, (sum, prod) => sum += (prod.Size * 25));
        }

        public void GroupBy()
        {
            var result = Products.GroupBy(prod => prod.Size).Select(prod => new
            {
                Size = prod.Key,
                Sum = prod.Sum(m => m.Size)
            });
        }

        /// <summary>
        /// Compares two collections for equality
        /// Simple Data Types(int,decimal,etc.)-check values
        /// Object Data Type checks reference
        /// Use Comparer Class to check for values of object types
        /// Same for Except(),Intersect()
        /// Union() checks for duplicate and Concat() doesn't check for duplicates
        /// </summary>
        public void SequenceEqual()
        {
            var list1 = new List<Products>
            {
                new Products {ProductId = 2345, ProductName = "TV", Size = 10},
                new Products() {ProductId = 3455, ProductName = "WATCH", Size = 15}
            };
            var list2 = new List<Products>
            {
                new Products {ProductId = 2345, ProductName = "TV", Size = 10},
                new Products() {ProductId = 3455, ProductName = "WATCH", Size = 15}
            };
            //var result = list1.GroupBy(prod => prod.ProductName);
             var result = list1.SequenceEqual(list2,new ProductComparer());
            //var result = list1.SequenceEqual(list2);
        }


    }
    /// <summary>
    /// 
    /// </summary>

    class ProductComparer : EqualityComparer<Products>
    {
        public override bool Equals(Products x, Products y)
        {
            return x?.ProductName == y?.ProductName && x?.ProductId == y?.ProductId && x?.Size == y?.Size;
        }

        public override int GetHashCode(Products obj)
        {
            return obj.ProductId;
        }
    }


}
