﻿using System;
using System.Collections.Generic;

namespace AdapterPattern
{
    class Employee
    {
        public string Name  { get; set; }
        public int EmployeeId { get; set; }
    }

    class EmployeeManager
    {
        public List<Employee> EmployeeList { get; set; }
        public EmployeeManager()
        {
            EmployeeList = new List<Employee>() {new Employee() {EmployeeId = 2333, Name = "Saroj"}};
            EmployeeList.Add(new Employee() { EmployeeId = 7777, Name = "Sandy" });
        }
        /// <summary>
        /// This is the older code where GetEmployees was giving an output in xml format
        /// </summary>
        /// <returns></returns>
        public virtual string GetEmployees()
        {
            //Here based on logic let say we are converting the employee list to xml and sending to client
            return string.Empty;
        }
    }
    //Now after some time th requirement changes and we have to convert the return into json type
    //Rather than changing directly in the source code what if will bring something like an interface and an
    //adapter class that adapter class will be used by the client ..
    //This Pattern is mostly used in legacy code and we didn't want to change old codes but we can still get new requirement done 
    interface IEmployee
    {
        string GetAllEmployees();
    }

    class EmployeeAdapter:EmployeeManager,IEmployee
    {
        public string GetAllEmployees()
        {
            //This is where we will get results in xml
            var result = base.GetEmployees();
            //Convert this result xml to json and resend it
            //Conversion started and conversion done
            return "Converted value in json format";
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Here client will call the adapter class 
            IEmployee employee = new EmployeeAdapter();
            employee.GetAllEmployees();

        }
    }
}
