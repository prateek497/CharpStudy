﻿using System;

namespace CSharp7._0
{
    class Program
    {
        static void Main(string[] args)
        {

            //var tupleTest = (value1:1, value2:2);
            //var newValue = ("name1", "name2");
            //int count = 5;
            //string label = "Colors used in the map";
            //var pair = (count, label); // element names are "count" and "label"
            //var value = QueryCityData("New york City");
            //var (_, pop, _) = QueryCityData("");
            D d = new D(10);
        }
        private static (string name, int pop, double size) QueryCityData(string name)
        {
            if (name == "New York City")
                return (name, 8175133, 468.48);

            return ("", 0, 0);
        }

    }
    public class B
    {
        public B(int i, out int j)
        {
            j = i;
        }
    }
    -
    public class D : B
    {
        public D(int i) : base(i, out var j)
        {
            Console.WriteLine($"The value of 'j' is {j}");
        }
    }
}
