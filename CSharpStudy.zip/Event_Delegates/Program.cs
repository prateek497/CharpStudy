﻿using System;

namespace Event_Delegates
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var worker = new Worker();
            //First check this
            // worker.WorkPerformed += new EventHandler<WorkTypeEventArgs>(WorkPerformedCallBack);
            // worker.WorkCompleted += new EventHandler(WorkCompletedCallback);

            //Second Check this
            #region Lambda
            worker.WorkPerformed += (s, e) => Console.WriteLine("Hours Started " + e.Hour + "WorkType: " + e.WorkType);
            worker.WorkCompleted += (s, e) => Console.WriteLine("Work Completed");
            #endregion
            worker.DoWork(15,WorkType.PlayGame);

            //Third Check This

            #region FuncDelegates
            
            if (args.Length>1)
            {
                Func<int, int, int> addFunc = ((x, y) =>  x + y);
                PerformCalculation(2, 3, addFunc);
            }
            else
            {
                Func<int, int, int> mulFunc = ((x, y) => x * y);
                PerformCalculation(2, 3, mulFunc);
            }
            

            #endregion
        }

        private static void WorkPerformedCallBack(object sender, WorkTypeEventArgs eventArgs)
        {
            Console.WriteLine("Hours Started " + eventArgs.Hour + "WorkType: " + eventArgs.WorkType);
        }
         
        private static void WorkCompletedCallback(object sender,EventArgs eventArgs)
        {            
            Console.WriteLine("Work Completed");
        }
        /// <summary>
        /// Func Delegate Method which return output based on logic which is set dynamically from source
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="funcDelegate"></param>
        /// <returns></returns>
        private  static int PerformCalculation(int x,int y,Func<int,int, int> funcDelegate)
        {
            //This is the invocation place
            var result = funcDelegate(x, y);
            Console.WriteLine(result);
            return result;
        }
    } 
}
