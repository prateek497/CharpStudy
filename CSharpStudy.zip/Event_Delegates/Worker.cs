﻿using System;

namespace Event_Delegates
{
    public enum WorkType
    {
        Meeting,
        PlayGame,
        CompleteCode
    }

    public class WorkTypeEventArgs:EventArgs
    {
        public WorkTypeEventArgs(int hour,WorkType workType)
        {
            Hour = hour;
            WorkType = workType;
        }
        public int Hour { get; set; }
        public WorkType WorkType { get; set; }
    }
    public class Worker
    {
        //This is the default event ehich .net gives if u just need to send some notification then just use it
        public event EventHandler WorkCompleted;
        //This is the custom way of sending event args data to the reciever
        public event EventHandler<WorkTypeEventArgs> WorkPerformed; 

        public void DoWork(int hours,WorkType workType)
        {
            for (int i = 0; i < hours; i++)
            {
                OnWorkPerformed(i+1,workType);
            }
            OnWorkCompleted();
        }

        protected virtual void OnWorkPerformed(int hour,WorkType workType)
        {
            WorkPerformed?.Invoke(this,new WorkTypeEventArgs(hour,workType));
        }
        protected virtual void OnWorkCompleted()
        {
            //Always check for null while invoking events might be chance there are no listners it will give error
            WorkCompleted?.Invoke(this, EventArgs.Empty);
        }
    }
}
