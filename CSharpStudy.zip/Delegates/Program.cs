﻿using System;
using System.ComponentModel;

namespace Delegates
{
    public delegate void WorkPerformedHandler(int hours, WorkType work);

    internal class Program
    {
        private static void Main(string[] args)
        {
            WorkPerformedHandler del1 = new WorkPerformedHandler(WorkPerformed_1);
            WorkPerformedHandler del2 = new WorkPerformedHandler(WorkPerformed_2);
            WorkPerformedHandler del3 = new WorkPerformedHandler(WorkPerformed_3);
            //Multicast Delegate
            del1 += del2 + del3;//Mostly useful in case of events where multiple listeners are present.Here things are added in invocation list so d1,d2,d3
            //For scenario if u want to return something from the method then var value=del1.Invoke(1,WorkType.CompleteCode); will give output of d3 return value 
            //which means the last one which is present in the invocation list.
            del1.Invoke(1,WorkType.CompleteCode);
         //   del2.Invoke(20,WorkType.PlayGame);
            // DoWork(del);
        }

        private static void DoWork(WorkPerformedHandler delHandler)
        {
            delHandler(1, WorkType.Meeting);

        }

        private static void WorkPerformed_1(int hours, WorkType work)
        {
            Console.WriteLine("WorkPerformed_1 is called with hours:" + hours);
        }

        private static void WorkPerformed_2(int hours, WorkType work)
        {
            Console.WriteLine("WorkPerformed_2 is called with hours:" + hours);
        }
        private static void WorkPerformed_3(int hours, WorkType work)
        {
            Console.WriteLine("WorkPerformed_3 is called with hours:" + hours);
        }
    }

    public enum WorkType
    {
        Meeting,
        PlayGame,
        CompleteCode
    }
}
