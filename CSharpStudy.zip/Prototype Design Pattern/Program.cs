﻿using System;
using System.Numerics;

namespace Prototype_Design_Pattern
{
    class Program
    {
        static void Main(string[] args)
        {
            Test t1 = new Test();
            t1.Name = "Saroj";
            t1.emp = new Employee() {Address = "Dhenkanal", Phonenumber = 8050825438};
            Test t2 = t1.DeepCopy();
            t2.Name = "Changed";
            t2.emp.Address = "Angul";
            Console.WriteLine(t1.emp.Address);
            //t1 = new Test();
            //Test2(ref t1);
            //Console.Write(t1.Name);
        }

        static void Test2(ref Test t2)
        {
            //t2 = new Test();
            t2.Name = "Testroyz";
        }
    }

    class Test
    {
        public string Name { get; set; }
        public Employee emp { get; set; }
        public Test CloneMe()
        {
            return (Test)this.MemberwiseClone();
        }

        public Test DeepCopy()
        {
            Test t1= (Test)this.MemberwiseClone();
            t1.emp = new Employee(){Address = this.emp.Address,Phonenumber = this.emp.Phonenumber};
            return t1;
        }
    }

    class Employee
    {
        public string Address { get; set; }
        public long  Phonenumber { get; set; }
    }
}
