﻿using System;

namespace MethodOverriding
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car = new Minivan();
            car.Show();
        }
    }
    class Car
    {
        public virtual void Show()
        {
            Console.WriteLine("From car");
        }
    }

    class Convertablecar : Car
    {
        public override void Show()
        {
            Console.WriteLine("From Convertable Car");
        }
    }

    class Minivan : Convertablecar
    {
        public new void Show()
        {
            Console.WriteLine("From Minivan");
        }
    }
}
