﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BinaryTree
{
    class BinaryTree
    {
        public BinaryTree(int parent) => Parent = parent;
        public  int Parent { get; set; }
        public BinaryTree Left { get; set; }
        public BinaryTree Right { get; set; }
    }
     class Program
     {
         private static List<int> arList = new List<int>();
         static Stack<int> stackList = new Stack<int>();
         private static int runningSum = 0;

        static void Main(string[] args)
        {
            BinaryTree binaryTree = new BinaryTree(parent: 1)
            {
                Left = new BinaryTree(parent: 2)
                {
                    Left = new BinaryTree(parent: 4)
                    {
                        Left = new BinaryTree(8),
                        Right = new BinaryTree(9)
                    }, 
                    Right = new BinaryTree(parent: 5)
                    {
                        Left = new BinaryTree(10),
                    }
                },
                Right = new BinaryTree(parent: 3)
                {
                    Left = new BinaryTree(parent: 6), 
                    Right = new BinaryTree(parent: 7)
                }
            };
            SumTraverse(binaryTree: binaryTree);
        }

        static void SumTraverse(BinaryTree binaryTree)
        {
            Console.WriteLine(binaryTree.Parent);
            runningSum += binaryTree.Parent;
           // stackList.Push(binaryTree.Parent);
            if (binaryTree.Left != null) SumTraverse(binaryTree.Left);
            if (binaryTree.Right != null) SumTraverse(binaryTree.Right);
            arList.Add(runningSum);
            runningSum = runningSum - binaryTree.Parent;
            //stackList.Pop();
        }
        /// <summary>
        /// Default Traversal
        /// </summary>
        /// <param name="binaryTree"></param>

        static void Traverse(BinaryTree binaryTree)
        {
            Console.WriteLine(binaryTree.Parent);
            if (binaryTree.Left !=null)
            {
               Traverse(binaryTree.Left); 
            }
            if (binaryTree.Right != null)
            {
                Traverse(binaryTree.Right);
            }
        }
    }
}
