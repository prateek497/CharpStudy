﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Program
    {
        //T1
       // TestAsync().GetAwaiterGetResult()//;
       //hdhd
       //gdhd
       //T1= TestAsync()
       //T2=TestAsync(CancellationToken token)1
       //T3=TestAsync()
       //Task.WhenAll(T1.Result,T2.Result,T3.Result)
        
        //async Task TestAsync();
        public delegate void MyDelegate();

        class A1:EqualityComparer<A1>
        {
            //public override bool Equals(object? obj)
            //{
            //    if (obj is A1 objA1)
            //    {
            //        return objA1.IntitalNumber == this.IntitalNumber;
            //    }
            //    return false;
            //}
            public int IntitalNumber { get; set; }
            public override bool Equals(A1 x, A1 y)
            {
                throw new NotImplementedException();
            }

            public override bool Equals(object? obj)
            {
                return base.Equals(obj);
            }

            public override int GetHashCode(A1 obj)
            {
                throw new NotImplementedException();
            }
        }
        static void ChangeNumber(A1 a)
        {
            a = new A1();
            a.IntitalNumber = 40;
        }

        class Employee
        {
            public virtual void Display()
            {
                Console.WriteLine("1");
            }
        }

        class Department:Employee
        {
            public new void Display()
            {
                Console.WriteLine("2");
            }
        }

        class Test
        {
            public void Display(Employee obj)
            {
                Console.WriteLine("1");
            }
            public void Display(Department obj)
            {
                Console.WriteLine("1");
            }
        }

        class  TestCtor
        {
            private TestCtor() { }
            public TestCtor(int i) { }
        }
        static void Main(string[] args)
        {
            TestCtor ctor = new TestCtor(1);
            //PlusOne(new[] {4, 3, 2, 1});
            //A1 a = new A1();
            //a.IntitalNumber = 20;
            //A1 b=null;
            //if (a.Equals(b)) Console.WriteLine("Equal Method");
            //if (a==b)
            //{
            //    Console.WriteLine("== Method");
            //}

            // SortedList<A> gList = new SortedList<A>();
            // Console.ReadLine();

            //Car c = new Car();
            //Minivan cMinivan = new Minivan();
            //MyDelegate del = new MyDelegate(c.Show);
            //MyDelegate del1 = new MyDelegate(cMinivan.Show);
            //MyDelegate del2 = new MyDelegate(() => Console.WriteLine("From anonymous method"));
            //del += del1 + del2;
            //del.Invoke();

            //Func<string, string> func = ((s) => s + "Working");
            //Action<string> action = Console.WriteLine;
            //action.Invoke("Test");

            //Car c = new Convertablecar();
            //var test2 = c is Minivan;
            //if (c is Convertablecar minivan)
            //{
            //   minivan.Show();
            //}
            //if (c is Minivan minivan1)
            //{
            //    minivan1.Show();
            //}
            //if (c is Car minivan2)
            //{
            //    minivan2.Show();
            //}
        }
        //100|4332|
        //     
        public static  int[] PlusOne(int[] digits)
        {
            var sum = 0;
            var length = digits.Length;
            foreach (var item in digits)
            {
                sum += item * Convert.ToInt32(Math.Pow(10, length - 1));
                length--;
            }
            sum = sum + 1;
            var newLength = Convert.ToInt32(Math.Floor(Math.Log10(sum) + 1)); 
            var array = new int[newLength];
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = sum / Convert.ToInt32(Math.Pow(10, newLength - 1));
            }
            return new int[5];
        }



        static void CallbackFunction(string s,Func<string,string> func)
        {
            func.Invoke(s);
        }

    }

    class Car
    {
        public virtual void Show()
        {
            Console.WriteLine("From car");
        }
    }

    class Convertablecar:Car
    {
        public override  void Show()
        {
            Console.WriteLine("From Convertable Car");
        }
    }

    class Minivan:Convertablecar
    {
        public new  void Show()
        {
            Console.WriteLine("From Minivan");
        }
    }

     class A
    {
        static A()
        {
            Console.WriteLine("Static:-A");
        }

        //public A()
        //{
        //    Console.WriteLine("Non Static:-A");
        //}
        public A(string name)
        {
            Console.WriteLine($"{name}");
        }

        public string  Test { get; set; }
    }

    class B:A
    {
        static B()
        {
            Console.WriteLine("Static:-B");
        }

        public B():this("name")
        {
            Console.WriteLine("Non Static:-B");
        }

        public B(string name):base(name)
        {
            Console.WriteLine("Non Static:-B");
        }

        public void Add()
        {
            Test = "From B";
        }
    }
}