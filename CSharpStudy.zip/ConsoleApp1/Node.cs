﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class Node
    {
        public int Left { get; set; }
        public int Right { get; set; }
    }

    class Parent
    {

        public Node Left { get; set; }
        public Node Right { get; set; }
        public int ParentValue { get; set; }
    }

}
