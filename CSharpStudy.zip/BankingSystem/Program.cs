﻿using System;
using BankingSystem.classes;

namespace BankingSystem
{
    class Program

    {
        static void Main(string[] args)
        {
            BankAccount account = new BankAccount("Saroj", 1000);
            account.MakeDeposit(-500,DateTime.Now, "New Deposit");
            account.MakeWithDraw(450,DateTime.Now, "Need Money");
            Console.WriteLine($"Account {account.Number} was created for {account.Owner} with {account.Balance} initial balance.");
            account.GetTransactionHistory();
        }
    }
}
