﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Channels;

namespace BankingSystem.classes
{
    public class BankAccount
    {
        public string Number { get; set; }
        public string Owner { get; set; }
        private readonly decimal MinimumBalance;

        public decimal Balance
        {
            get
            {
                return TransactionList.Sum(item => item.Amount);
            }
            
        }

        private static int _accountNumberSeed = 1234567;
        private List<Transaction> TransactionList { get; set; }

        public BankAccount(string name, decimal initialBalance)
        {
            Owner = name;
            Number = _accountNumberSeed.ToString();
            _accountNumberSeed++;
            TransactionList = new List<Transaction> { new Transaction(initialBalance, DateTime.Now, "Initial Entry") };
        }

        public BankAccount(string name, decimal initialBalance,decimal minimumbalance):this(name,initialBalance)
        {
            this.MinimumBalance = minimumbalance;
        }
        /// <summary>
        /// Make Deposit
        /// </summary>
        /// <param name="amount"></param>
        /// <param name="date"></param>
        /// <param name="note"></param>
        public void MakeDeposit(decimal amount, DateTime date, string note)
        {
            if (amount <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(amount), "Amount of deposit must be positive");
            }
            TransactionList.Add(new Transaction(amount, date, note));
        }
        /// <summary>
        /// Withdraw Amount
        /// </summary>
        /// <param name="amount"></param>
        /// <param name="date"></param>
        /// <param name="note"></param>
        public void MakeWithDraw(decimal amount, DateTime date, string note)
        {
            if (amount <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(amount), "Amount of withdrawal must be positive");
            }
            if (Balance - amount < 0)
            {
                throw new InvalidOperationException("Not sufficient funds for this withdrawal");
            }
            TransactionList.Add(new Transaction(-amount, date, note));
        }
        /// <summary>
        /// Get Transaction History
        /// </summary>
        public void GetTransactionHistory()
        {
            foreach (var item in TransactionList)
            {
                Console.WriteLine($"{item.Date.ToShortDateString()}\t{item.Amount}\t{Balance}\t{item.Notes}");
            }
        }
    }
}
