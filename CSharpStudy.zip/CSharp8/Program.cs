﻿using System;

namespace CSharp8
{
    interface ICustomer
    {
        void Add();

        void CalculateDiscount()
        {
            Console.WriteLine("From Interface");
        }
    }

    class SampleUser:ICustomer
    {
        public void Add()
        {
            throw new NotImplementedException();
        }
       //public void CalculateDiscount()
       // {
       //     Console.WriteLine("From Sample User");
       // }
    }
    class Program
    {
        public static string[] Words = new string[]
        {
            // index from start    index from end
            "The",      // 0                   ^9
            "quick",    // 1                   ^8
            "brown",    // 2                   ^7
            "fox",      // 3                   ^6
            "jumped",   // 4                   ^5
            "over",     // 5                   ^4
            "the",      // 6                   ^3
            "lazy",     // 7                   ^2
            "dog"       // 8                   ^1
        };              // 9 (or words.Length) ^0
        static void Main(string[] args)
        {
            //var quickBrownFox = Words[1..4];
            //Console.WriteLine($"The last word is {Words[^1]}");
            //var phases = 1..4;
            //var text=Words[phases];
            ICustomer user = new SampleUser();
            user.CalculateDiscount();
        }

    }
}
