﻿using System;

namespace SingleTon
{
    class Program
    {
        static void Main(string[] args)
        {
            Lazy<MyClass> myClassLazy = new Lazy<MyClass>(() => new MyClass());
            var test=myClassLazy.Value.Myname;
            //var value=MyClass.Myname;
        }
    }

    class MyClass
    {
        public  string Myname => "MyName";
        static MyClass()
        {
            Console.WriteLine("Static MyClass");
        }

        public MyClass()
        {
            Console.WriteLine("Non Static MyClass");
        }
    }
    //Eager loading
    sealed class SingleTon
    {
        private SingleTon()
        {

        }

        private static readonly SingleTon singleTon = new SingleTon();

        public static SingleTon GetInstanceSingleTon()
        {
            return singleTon;
        }
    }
    //Lazy loading
    sealed class SingleTonLazy
    {
        private SingleTonLazy()
        {

        }

        private static readonly Lazy<SingleTonLazy> singleTonLazy = new Lazy<SingleTonLazy>(() => new SingleTonLazy());

        public static SingleTonLazy GetInstance() => singleTonLazy.Value;
    }
}
