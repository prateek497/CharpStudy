﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Generics
{

    class GenericList:List<int>
    {
        
    }
    class Program
    {
        static void Main(string[] args)
        {
            GenericList genericList = new GenericList();
            genericList.Add(1);
            Test t = new Test();
            t.Show(2);
            A<string>.B.C c = new A<string>.B.C();
            c.M();
        }
    }
    public class A<T>
    {
        public class B : A<int>
        {
            public void M()
            {
                Console.WriteLine(typeof(T).ToString());
            }
            public class C : B { }
        }
    }
    //Testing
    public class Test
    {

        public T Show<T>(T a)
        {
            return a;
        }
    }
}
