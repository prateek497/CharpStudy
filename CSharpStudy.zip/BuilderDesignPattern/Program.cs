﻿using System;

namespace BuilderDesignPattern
{
   public interface IVehicleBuilder
    {
       void CreateEngine();
       void ApplyPaintColor();
       Vechile GetVechile();
   }

   public class Vechile
   {
       public Vechile(string model)
       {
           Model = model;
       }

       private readonly string Model;
       public string Engine { get; set; }
       public string VechileColor { get; set; }

    }
    /// <summary>
    /// Concrete Builder
    /// </summary>
    class ScotterBuilder : IVehicleBuilder
    {
        private Vechile vechile = new Vechile("Honda");
        
        public void ApplyPaintColor()
        {
            vechile.VechileColor = "Green";
        }

        public void CreateEngine()
        {
            vechile.Engine = "150cc";
        }

        public Vechile GetVechile()
        {
            return vechile;
        }
    }
    /// <summary>
    /// Director class
    /// </summary>
    public class VehicleCreator
    {
        private readonly IVehicleBuilder _objBuilder;

        public VehicleCreator(IVehicleBuilder builder)
        {
            _objBuilder = builder;
        }
        //This is where it is making sure the way a vehicle should process
        public void CreateVehicle()
        {
           _objBuilder.CreateEngine();
           _objBuilder.ApplyPaintColor();
        }

        public Vechile GetVehicle()
        {
            return _objBuilder.GetVechile();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            VehicleCreator obj = new VehicleCreator(new ScotterBuilder());
            obj.CreateVehicle();
            obj.GetVehicle();
        }
    }
}
