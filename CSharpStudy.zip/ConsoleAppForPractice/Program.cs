﻿using System.Collections.Generic;
using System;
using System.Linq;

class A
{
    public void Add()
    {

    }
}

class B:A
{
    public void Sub()
    {

    }
}

public class Program
{
    static void Main()
    {
        B a = new B();
    }

    public static Dictionary<string, int> dict = new Dictionary<string, int>();
    public static string TournamentWinner(List<List<string>> competitions, List<int> results)
    {
        // Write your code here.
        for (int i = 0; i <= competitions.Count - 1; i++)
        {
            var winner = results[i] == 1 ? competitions[i][0] : competitions[i][1];
            if (!dict.ContainsKey(winner))
            {
                dict.Add(winner, 3);
            }
            else
            {
                dict[winner] = dict[winner] + 3;
            }
        }
        var currentValue = 0;
        var winnerValue = "";
        for (int i = 0; i <= dict.Count - 1; i++)
        {
            currentValue = dict.ElementAt(i).Value > currentValue ? dict.ElementAt(i).Value : currentValue;
            
        }
        Console.WriteLine(winnerValue);
        return winnerValue;
    }
}