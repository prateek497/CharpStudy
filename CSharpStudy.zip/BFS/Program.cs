﻿using System;
using System.Collections.Generic;

namespace BFS
{
    class Program
    {
        private static Queue<Node> queue = new Queue<Node>();
        static void Main(string[] args)
        {
            Node node = new Node("A");
            node.Children.Add(new Node("B"));
            node.Children.Add(new Node("C"));
            node.Children[0].Children.Add(new Node("D"));
            node.Children[0].Children.Add(new Node("E"));
            node.Children[1].Children.Add(new Node("F"));
            queue.Enqueue(node);
            TraverseNodeBFS();
        }

        /// <summary>
        /// O(V)
        /// O(1)
        /// </summary>
        /// <param name="node"></param>
        static void TraverseNodeDFS(Node node)
        {
            Console.WriteLine(node.Parent);
            foreach (var item in node.Children)
            {
                TraverseNodeDFS(item);   
            }
        }
        /// <summary>
        /// O(V +E)
        /// Space O(V)
        /// </summary>
        static void TraverseNodeBFS()
        {
            while (queue.Count>0)
            {
                Node node = queue.Dequeue();
                Console.WriteLine(node.Parent);
                foreach (var item in node.Children)
                {
                    queue.Enqueue(item);
                }
                TraverseNodeBFS();
            }
            
        }
        public class Node
        {
            public Node(string parent)
            {
                Children = new List<Node>();
                Parent = parent;
            }
            public string Parent { get; set; }
            public List<Node> Children { get; set; }
        }
    }
}
